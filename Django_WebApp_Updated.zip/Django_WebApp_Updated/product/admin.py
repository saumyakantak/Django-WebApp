from .models import Product
from django.contrib import admin


admin.site.register(Product)
# Register your models here.
